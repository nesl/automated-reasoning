# automated-reasoning
CS264A: Automated Reasoning: Course Project (SAT Solver and Knowledge compiler) SP 2015
