/*
 * ParseDIMACS.h
 *
 *  Created on: Apr 30, 2015
 *      Author: salma
 */

#ifndef PARSEDIMACS_H_
#define PARSEDIMACS_H_

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int parseDIMACS(FILE* cnf_file);



#endif /* PARSEDIMACS_H_ */
